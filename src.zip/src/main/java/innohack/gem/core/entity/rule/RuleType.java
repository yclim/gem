package innohack.gem.core.entity.rule;

public enum RuleType {
  FILE,
  TIKA_CONTENT,
  TIKA_METADATA,
  CSV,
  EXCEL
}
