package innohack.gem.core.entity.rule;

public enum ParamType {
  REGEX,
  INT,
  STRING,
  STRING_LIST
}
